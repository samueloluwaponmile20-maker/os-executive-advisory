OS EXECUTIVE ADVISORY — WEBSITE FILES

Included:
- index.html: complete responsive website in one file.

HOW TO PREVIEW
1. Download and unzip the package.
2. Open index.html in Chrome, Edge, or Firefox.

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Search for REPLACE-WITH-YOUR-EMAIL@example.com and replace it with your real professional email address.
3. Review the biography and all service descriptions to ensure they accurately reflect your practice.
4. The testimonials section intentionally contains no fabricated endorsements. Replace it only with genuine, permission-approved client feedback.
5. The contact form currently opens the visitor's email application; it is not a server-backed form. For a working hosted form, connect a form service or a secure endpoint.
6. Add a privacy policy that reflects how you collect, store, and use enquiries.
7. Publish using a free static host such as GitHub Pages or Netlify's free tier, checking their current plan terms first.

This is a starter website template. It does not purchase a domain or publish itself online.
